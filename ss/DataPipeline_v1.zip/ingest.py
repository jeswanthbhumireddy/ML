class Ingest:
    def ingest_data(self):
        print("Ingesting")
