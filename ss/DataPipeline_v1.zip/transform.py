class Transform:
    def transform_data(self):
        print("Transforming")