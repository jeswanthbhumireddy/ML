class Persist:
    def persist_data(self):
        print("Persisiting")