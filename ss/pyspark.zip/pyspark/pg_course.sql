CREATE TABLE futurexschema.futurex_course
(
    course_id character varying COLLATE pg_catalog."default" NOT NULL,
    course_name character varying COLLATE pg_catalog."default" NOT NULL,
    author_name character varying COLLATE pg_catalog."default" NOT NULL,
    no_of_reviews character varying COLLATE pg_catalog."default" NOT NULL
);

select * from futurexschema.futurex_course;